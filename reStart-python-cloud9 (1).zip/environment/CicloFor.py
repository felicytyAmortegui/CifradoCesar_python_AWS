print("Cuenta hasta 10!")

valorRetroceso = 10
for x in range (0, 11):
    print(x)
    valorRetroceso -=1
    print("Cuenta regresiva: {}" .format(valorRetroceso))
    
