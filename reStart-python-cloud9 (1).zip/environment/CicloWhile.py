# Programa que usa while e if para generar un juego de "Adivina el número".
import random
print("Adivina el número!")
print("Las reglas son simples: yo pensaré en un número, \n"
"y tu trata de adivinarlo.")

numeroAleatorio = random.randint(1,10)  #llama a la libreria random y genera el numero aleatorio.
valorCorrecto = False #Indicador para romper el ciclo

while valorCorrecto != True: # Condicional de permanencia del ciclo
    datoUsuario = input("Adivina un numero entre 1 y 10: ")
    if int(datoUsuario) == numeroAleatorio:
        print("Ganaste!!!" .format(datoUsuario))
        valorCorrecto = True
    else:
        print("el número no es el que pense yo :( , intelalo de nuevo! ")


    