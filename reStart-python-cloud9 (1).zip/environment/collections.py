fruitList = ["Apple", "Banana", "Cherry", "Lemon", "Strawberry"]
#print(fruitList)
#print(type(fruitList))
#fruitList[0]= "Orange"
#print(fruitList[0])
print(fruitList)
fruitList.insert(len(fruitList), "Mango")
print(fruitList)

# EJERCICIO TUPLAS:

tuplaFrutas = ("Apple", "Banana", "Cherry", "Lemon", "Strawberry")
print(type(tuplaFrutas))
print(tuplaFrutas)
# Ejercicio diccionario
myDictionary = {"1" : "Manzanas", 
                "2" : "Bananas", 
                "3" : "Cerezas",
                "4" : "Limones",
}
print(myDictionary)
print(myDictionary["1"])