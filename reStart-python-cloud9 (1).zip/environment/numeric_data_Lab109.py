#print("Python has three numeric types: int, float, and complex")
variable = 12
variable2 = 3.14
variableComplex = 5j
variableBool=True

#print(variable)
#print(type(variable))
#print(str(variable) + " is of the data type " + str(type(variable)))

print(variable2)
print(type(variable2))
print(str(variable2) + " is of the data type " + str(type(variable2)))

#print(variableComplex)
#print(type(variableComplex))
#print(str(variableComplex) + " is of the data type " + str(type(variableComplex)))

#print(variableBool)
#print(type(variableBool))
#print(str(variableBool) + " is of the data type " + str(type(variableBool)))

