listaMixta = [2.56, "A", "Hola", 37, -20, False, "2022"]
contador = 0
for valorLista in listaMixta:
    print("{} es un tipo de dato {}".format(valorLista, type(valorLista)))
    contador += 1
    print(contador)
