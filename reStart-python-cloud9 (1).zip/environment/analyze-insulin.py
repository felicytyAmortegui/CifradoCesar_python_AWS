cadenaProteina = "ORIGIN     1 malwmrllpl lallalwgpd paaafvnqhl cgshlvealy lvcgergffy tpktrreaed61 lqvgqvelgg gpgagslqpl alegslqkrg iveqcctsic slyqlenycn// "

sinEspacios = cadenaProteina.replace(" ","").replace("ORIGIN","").replace("1","").replace("6","").replace("//","")
print (sinEspacios) 

lectura = open("preproinsulin-seq-clean.txt", "rt")
lsinsulin = open("lsinsulin-seq-clean.txt", "wt")
binsulin = open("lsinsulin-seq-clean.txt", "wt")
cinsulin = open("lsinsulin-seq-clean.txt", "wt")
ainsulin = open("lsinsulin-seq-clean.txt", "wt")

for linea in lectura:
     lsinsulin.write(linea[0:24])
     print("La cadena es: {} y su longitus es de {} letras ".format(linea[0:24],len(linea[0:24])))
     binsulin.write(linea[24:54])
     print("La cadena es: {} y su longitus es de {} letras ".format(linea[24:54],len(linea[24:54])))
     cinsulin.write(linea[54:89])
     print("La cadena es: {} y su longitus es de {} letras ".format(linea[54:89],len(linea[54:89])))
     ainsulin.write(linea[89:110])
     print("La cadena es: {} y su longitus es de {} letras ".format(linea[89:110],len(linea[89:110])))

lectura.close
lsinsulin.close
binsulin.close
cinsulin.close
ainsulin.close

    
    



