#respuestaUser = input("Necesitas enviar un paquete?, Envia si o no: ")

#if respuestaUser == "si":
    #print("¡Podemos ayudarte a enviar este paquete! ")
#else:
    #print("Regresa cuando tengas un paquete para enviar. ")

entrada = input("Que te gustaría comprar?: dulces, juguetes, o comida?: ")
respuesta = entrada.lower()
if respuesta == "dulces":
    print("Bienvenido a la tienda de dulces!")
elif respuesta == "juguetes":
    print("Bienvenido a la seccion de juguetes!.")
elif respuesta == "comida":
    copies = input("Bienvenido al mejor restaurante!")
    print("Here are {} copies.".format(copies))
else:
    print("Ingresa una opción valida. ")