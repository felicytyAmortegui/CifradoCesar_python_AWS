#cadena1 = "Esta es una cadena de caracteres"
#print(cadena1)
#print(type(cadena1))
#numero = 37
#print(cadena1 + " is of the data type " + str(type(cadena1)))

#cadenaY= "Yurany"
#cadenaA = "Amortegui"
#concatenar = cadenaY + cadenaA
#print("Mi nombre es: " + concatenar + " y tengo " + str(numero) + " años." )

nombre = input("Escribe tu nombre: ")
color = input("Cual es tu color favorito? : ")
animal = input("Cual es tu animal favorito: ")
print(nombre + color + animal)
print("{}, te gusta el color {} y tu animal es {} !".format(nombre, color, animal) )



